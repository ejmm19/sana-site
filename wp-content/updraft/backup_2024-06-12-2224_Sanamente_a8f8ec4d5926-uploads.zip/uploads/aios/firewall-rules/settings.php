<?php __halt_compiler();
/**
 * This file was created by All In One Security (AIOS) plugin.
 * The file is required for storing and retrieving your firewall's settings.
 */
{"aios_enable_rename_login_page":"","aios_login_page_slug":"","aios_enable_brute_force_attack_prevention":"","aios_brute_force_secret_word":"","aios_cookie_based_brute_force_redirect_url":"http:\/\/127.0.0.1","aios_brute_force_attack_prevention_pw_protected_exception":"","aios_brute_force_attack_prevention_ajax_exception":"","aios_brute_force_secret_cookie_name":"aios_brute_force_secret_de247254482ab38afd50a0e8c4a78b86","aios_ip_retrieve_method":0,"aiowps_ip_retrieve_method":"","aiowps_blacklist_ips":[],"aiowps_blacklist_user_agents":[],"aiowps_block_fake_googlebots":false}