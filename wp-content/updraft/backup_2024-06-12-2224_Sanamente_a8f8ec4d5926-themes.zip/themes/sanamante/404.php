<?php get_header(); ?>
    <main class="container">
        <div class="page-404">
            <h1>404 not found</h1>
        </div>
    </main>
<?php get_footer(); ?>
