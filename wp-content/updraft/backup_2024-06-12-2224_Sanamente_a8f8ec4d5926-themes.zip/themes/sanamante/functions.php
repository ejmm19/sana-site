<?php

require_once 'hooks/products.php';
require_once 'hooks/orientadores.php';
require_once 'hooks/bootstrap.php';
require_once 'hooks/menu.php';
require_once 'hooks/footer.php';
require_once 'Model/Product.php';
require_once 'Model/Orientadores.php';
require_once 'Filters/translate.php';
require_once 'Shortcodes/main.php';
