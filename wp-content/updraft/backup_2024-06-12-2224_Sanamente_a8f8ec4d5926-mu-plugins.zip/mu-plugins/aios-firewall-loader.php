<?php
// Begin AIOWPSEC Firewall
if (file_exists('/home/u912106533/domains/sanamente.co/public_html/aios-bootstrap.php')) {
	include_once('/home/u912106533/domains/sanamente.co/public_html/aios-bootstrap.php');
}
// End AIOWPSEC Firewall
